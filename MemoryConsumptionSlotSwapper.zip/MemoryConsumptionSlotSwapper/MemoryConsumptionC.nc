#include "Timer.h"
#include "Permute.h"
#include <stdlib.h>

module MemoryConsumptionC @safe() 
{
    uses interface Leds;
    uses interface Boot;
  
    uses interface AMSend;
    uses interface Receive as R_A;
	uses interface Receive as R_B;
    uses interface Timer<TMilli> as Timer1;
    uses interface Timer<TMilli> as Timer2;
    //uses interface Timer<TMilli> as Timer3;
    //uses interface Timer<TMilli> as Timer4;
    uses interface SplitControl as AMControl;
    uses interface Packet;

    uses  interface Resource;
   	uses 	interface Msp430Adc12MultiChannel as MultiChannel;
    uses interface PacketAcknowledgements;
	provides 	interface AdcConfigure<const msp430adc12_channel_config_t*>;   
}
implementation 
{
	static int32_t val1;
	static int32_t val2;
	static int8_t buf_count;
	static bool lowpowersignal;

	static int32_t Buffer1[10];
	static int32_t Buffer2[10];
	static int16_t index;
    
    static Flow_t F[10];
	static Control_Loop_t Cntl[10];
    //Cluster Declaration
    //static Cluster_t C[10];

    int16_t unused_slots;
    int16_t total_hops = 0;

    message_t packet_s;
    message_t packet_r;
	message_t packet_rb;
	
    message_t* recvBuf;
    message_t* sendBuf;

    radio_count_msg_t* rcm;
    radio_count_msg_t* rcv;
	radio_count_msg_t* rcv_b;

    uint16_t timeslot = 0;

    //	ADCValues
	nx_uint16_t adcValues[2];
    uint16_t buffer[3];

    static slot_info_t BaseSchedule[12][120]; 

    task void initializeFlow();
    task void assignFlowstoSlots();
    task void initializeSchedule();

    const msp430adc12_channel_config_t config = {
		INPUT_CHANNEL_A5, REFERENCE_VREFplus_AVss, REFVOLT_LEVEL_2_5,
		SHT_SOURCE_SMCLK, SHT_CLOCK_DIV_1, SAMPLE_HOLD_64_CYCLES,
		SAMPCON_SOURCE_SMCLK, SAMPCON_CLOCK_DIV_1
	};

    event void Boot.booted() 
    {
		buf_count = 0;
		lowpowersignal = FALSE;

        call AMControl.start();
    }

    event void AMControl.startDone(error_t err) 
    {
        if (err == SUCCESS) 
        {
            post initializeFlow();
            post assignFlowstoSlots();
            post initializeSchedule();

            call Resource.request();
        }
        else 
        {
            call AMControl.start();
        }
    }

    event void AMControl.stopDone(error_t err) 
    {
        // do nothing
    }

    event void Resource.granted()
    {
	    atomic 
        {
		    adc12memctl_t memctl[] = { {INPUT_CHANNEL_A0, REFERENCE_VREFplus_AVss}, {INPUT_CHANNEL_A1, REFERENCE_VREFplus_AVss}};

		    if (call MultiChannel.configure(&config, memctl, 2, buffer, 3, 0) != SUCCESS) 
            {

		    }
	    }
	
        // Start a periodic timer to read the ADC
        call Timer1.startPeriodic(150);
        //Hyperperiod = 180ms
        call Timer2.startPeriodic(15);
    }
	
    task void initializeFlow()
    {
        //FLOW 1
        F[0].flow_id = 1;
		F[0].cntl_ID = 1;
		//F[0].cluster_id = 1;
        F[0].n_hops = 4;
        F[0].period = 10;
		F[0].n_inst = (HYPERPERIOD-1)/F[0].period;
        F[0].route[0][0] = 1;
        F[0].route[0][1] = 5;
		F[0].route[1][0] = 5;
        F[0].route[1][1] = 7;
        F[0].route[2][0] = 7;
        F[0].route[2][1] = 9;

        //FLOW 2
        F[1].flow_id = 2;
		F[1].cntl_ID = 2;
		//F[1].cluster_id = 1;
        F[1].n_hops = 4;
        F[1].period = 10;
		F[1].n_inst = (HYPERPERIOD-1)/F[1].period;
        F[1].route[0][0] = 2;
        F[1].route[0][1] = 5;
        F[1].route[1][0] = 5;
        F[1].route[1][1] = 8;
        F[1].route[2][0] = 8;
        F[1].route[2][1] = 9;

        //FLOW 3
        F[2].flow_id = 3;
		F[2].cntl_ID = 3;
		//F[2].cluster_id = 2;
        F[2].n_hops = 4;
        F[2].period = 15;
		F[2].n_inst = (HYPERPERIOD-1)/F[2].period;
        F[2].route[0][0] = 3;
        F[2].route[0][1] = 5;
        F[2].route[1][0] = 6;
        F[2].route[1][1] = 7;
        F[2].route[2][0] = 7;
        F[2].route[2][1] = 9;

        //FLOW 4
        F[3].flow_id = 4;
		F[3].cntl_ID = 4;
        //F[3].cluster_id = 2;
        F[3].n_hops = 4;
        F[3].period = 15;
		F[3].n_inst = (HYPERPERIOD-1)/F[3].period;
        F[3].route[0][0] = 4;
        F[3].route[0][1] = 5;
		F[3].route[1][0] = 6;
        F[3].route[1][1] = 8;
        F[3].route[2][0] = 8;
        F[3].route[2][1] = 9;
    }
	
    task void assignFlowstoSlots()
    {
		Cntl[0].period = 10;
		Cntl[1].period = 10;
		Cntl[2].period = 15;
		Cntl[3].period = 15;
		
		Cntl[0].available_periods[0] = 10;
		Cntl[0].available_periods[1] = 20;
		Cntl[0].available_periods[2] = 60;
		Cntl[1].available_periods[0] = 10;
		Cntl[1].available_periods[1] = 20;
		Cntl[1].available_periods[2] = 60;
		Cntl[2].available_periods[0] = 15;
		Cntl[2].available_periods[1] = 30;
		Cntl[2].available_periods[2] = 60;
		Cntl[3].available_periods[0] = 15;
		Cntl[3].available_periods[1] = 30;
		Cntl[3].available_periods[0] = 60;
		
    }

    task void initializeSchedule()
    {
        atomic
        {
            int i, j;
            
            for (i = 0;i < 1024;i++)
			{
				for (j = 0;j < 60;j++)
				{
					BaseSchedule[i][j].s = 10;
					BaseSchedule[i][j].r = 10;
					BaseSchedule[i][j].fid = 1;
				}
			}
        }
    }
	
    task void getData()
	{
		// Read ADC values
		call MultiChannel.getData();
	}

    event void Timer1.fired() 
    {
        post getData();
    }

    event void Timer2.fired()
    {
		int ran = rand()%2;
		if (lowpowersignal == FALSE)
		{
			if (BaseSchedule[ran][timeslot].s == TOS_NODE_ID)
			{
				rcm = (radio_count_msg_t*)call Packet.getPayload(&packet_s, sizeof(radio_count_msg_t));
				if (rcm == NULL) 
				{
					return;
				}
				else
				{
					atomic
					{
						rcm->Mantissa = Buffer1[(BaseSchedule[ran][timeslot].fid)];
						rcm->Exponent = Buffer2[(BaseSchedule[ran][timeslot].fid)];
					}
					rcm->fid = BaseSchedule[ran][timeslot].fid;
					if (call AMSend.send(BaseSchedule[ran][timeslot].r, &packet_s, sizeof(radio_count_msg_t)) == SUCCESS) 
					{
						dbg("RadioCountToLedsC", "RadioCountToLedsC: packet sent.\n", counter);	
					}
				}
				//call Leds.led0Toggle();
			} 
			else if (BaseSchedule[ran][timeslot].r == TOS_NODE_ID)
			{
				rcv = (radio_count_msg_t*)call Packet.getPayload(&packet_r, sizeof(radio_count_msg_t));
				recvBuf = signal R_A.receive(&packet_r, rcv, sizeof(radio_count_msg_t));
			}
		}
		else
		{
			rcv_b = (radio_count_msg_t*)call Packet.getPayload(&packet_rb, sizeof(radio_count_msg_t));
            sendBuf = signal R_B.receive(&packet_rb, rcv_b, sizeof(radio_count_msg_t));
			lowpowersignal = FALSE;
			//post PermutationCipher();
		}
		
		timeslot = timeslot + 1;
		
		if (timeslot == HYPERPERIOD - 1)
		{
			//lowpowersignal = TRUE;
		}
		
		if (timeslot == HYPERPERIOD)
		{
			timeslot = 0;
		}
		
    }

    event void AMSend.sendDone(message_t* bufPtr, error_t error) 
    {    
        if (&packet_s == bufPtr) 
        {
        }
    }
  
    event message_t* R_A.receive(message_t* bufPtr, void* payload, uint8_t len) 
    {
        radio_count_msg_t * r1 = (radio_count_msg_t*)payload;
        val1 = r1->Mantissa;
        val2 = r1->Exponent;
        index = r1->fid;
		atomic
		{
			Buffer1[index] = val1;
			Buffer2[index] = val2;
		}
		
        if (len != sizeof(radio_count_msg_t)) 
        {
            return bufPtr;
        }
        else 
        {
            return bufPtr;            
        }
    }  

    async event void MultiChannel.dataReady(uint16_t *buf, uint16_t numSamples)
	{
		// Copy sensor readings
		adcValues[0] = buf[1];
		adcValues[1] = buf[2];
        
        Buffer1[TOS_NODE_ID] = adcValues[0];
        Buffer2[TOS_NODE_ID] = adcValues[1];

    }

    async command const msp430adc12_channel_config_t* AdcConfigure.getConfiguration()
	{
		return &config;
	}
	
	event message_t* R_B.receive(message_t* bufPtr, void* payload, uint8_t len) 
    {
		int16_t j,k,l,val;
		
		rateMsg_t* r2 = (rateMsg_t*)payload;
		
		if (r2 != NULL)
		{
		
			if (len != sizeof(rateMsg_t)) 
			{
				return bufPtr;
			}
			else 
			{
				val = r2 -> R;
				
				for (j = 0;j < NUM_OF_CONTROLS;j++)
				{
					k = val%10;
					Cntl[j].period = Cntl[j].available_periods[k];
					for (l = 0;l < NUM_OF_FLOWS;l++)
					{
						if (F[l].cntl_ID == j+1)
						{
							F[l].period = Cntl[j].period;
							F[l].n_inst = (HYPERPERIOD-1)/Cntl[j].period;
						}
					}	
					val = val/10;
				}				
				//post updateSchedule();
				return bufPtr;            
			}
		}
		//post PermutationCipher();
		return bufPtr;
	}

}	
